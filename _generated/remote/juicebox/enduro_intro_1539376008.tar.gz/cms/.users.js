({
	users: [
		{
			username: 'hamadniaz',
			tags: [],
			salt: '99a6673ac52c5b282fafad3a6732788c',
			hash: '0ae668e5185806e87a40f4600397e5a69f3c258f85969d3418c47e8edd6f3e97',
			user_created_timestamp: 1539330165431
		}
	]
})